CREATE PROCEDURE getItemPrice(IN itemId INT, OUT itemPrice DECIMAL)
  BEGIN
    SELECT PRICE
    INTO itemPrice
    FROM ITEM
    WHERE ITEM_ID = itemId;
  END;
